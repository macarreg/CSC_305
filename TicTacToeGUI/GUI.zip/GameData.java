import java.beans.PropertyChangeSupport;

public class GameData extends PropertyChangeSupport {
    private final String[][] board = new String[3][3];
    private String currentPlayer = "X";

    public GameData(Object source) {
        super(source);
    }

    public boolean setCharacter(int row, int col) {
        if (board[row][col] == null) {
            board[row][col] = currentPlayer;
            firePropertyChange("board", null, board);
            switchPlayer();
            return true;
        }
        return false;
    }

    private void switchPlayer() {
        currentPlayer = currentPlayer.equals("X") ? "O" : "X";
        firePropertyChange("currentPlayer", null, currentPlayer);
    }
}

