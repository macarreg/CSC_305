import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class GameController implements MouseListener {
    private final GameData gameData;

    public GameController(GameData gameData) {
        this.gameData = gameData;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (e.getSource() instanceof Box box) {
            int row = box.getRow();
            int col = box.getCol();
            gameData.setCharacter(row, col);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}

