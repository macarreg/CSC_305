import javax.swing.*;

public class GameMain extends JFrame {
    public GameMain() {
        setTitle("Tic Tac Toe");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);

        GameData gameData = new GameData(this);
        GameController controller = new GameController(gameData);
        BoardPanel boardPanel = new BoardPanel(gameData, controller);

        add(boardPanel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GameMain mainWindow = new GameMain();
            mainWindow.setVisible(true);
        });
    }
}

