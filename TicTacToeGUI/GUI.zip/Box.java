import javax.swing.*;
import java.awt.*;

public class Box extends JButton {
    private final int row, col;

    public Box(int row, int col) {
        this.row = row;
        this.col = col;
        setFont(new Font("Arial", Font.BOLD, 40));
        setFocusPainted(false);
    }

    public int getRow() { return row; }
    public int getCol() { return col; }
}

