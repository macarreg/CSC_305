import javax.swing.*;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class BoardPanel extends JPanel implements PropertyChangeListener {
    private final GameData gameData;

    public BoardPanel(GameData gameData, GameController controller) {
        this.gameData = gameData;
        setLayout(new GridLayout(3, 3));

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                Box box = new Box(row, col);
                box.addMouseListener(controller);
                add(box);
            }
        }
        gameData.addPropertyChangeListener(this);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if ("board".equals(evt.getPropertyName())) {
            updateBoard((String[][]) evt.getNewValue());
        }
    }

    private void updateBoard(String[][] board) {
        Component[] components = getComponents();
        for (Component component : components) {
            if (component instanceof Box box) {
                String character = board[box.getRow()][box.getCol()];
                box.setText(character != null ? character : "");
            }
        }
    }
}

