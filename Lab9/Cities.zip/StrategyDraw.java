import java.awt.*;

public interface StrategyDraw {
    void drawConnect(Node node, Node b, Graphics g);
}
