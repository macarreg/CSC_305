import java.util.ArrayList;

public interface Strategy {

    int[] algorithm(ArrayList<Node> nodes);

}
